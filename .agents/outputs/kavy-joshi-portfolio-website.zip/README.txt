Kavy Joshi Portfolio — static website export

This archive contains the production-ready static site. Upload the files in this folder to the web root of any static hosting provider. Keep the assets folder beside index.html.

Included: index.html, compiled CSS/JavaScript, favicon.svg, and robots.txt.

The editable React/Vite project remains in the Replit project under artifacts/kavy-joshi-portfolio.
